麻将胡了2 UI/特效资源部署包
目标仓库：aaamao666666-lab/mahjong-hulu2-mobile
目标分支：feature/mahjong-hulu2-3d-upgrade

将 public/ 文件夹整体合并到仓库根目录的 public/，不要覆盖现有文件。
最终资源路径：public/assets/mahjong-hulu2/ui/ 与 effects/。

本包保留原始 PNG 文件与透明通道；来源于用户先前生成的 UI、金色中奖、免费旋转、连消与掉落素材。
素材中的部分龙纹原始裁切图本身不是透明 PNG（原素材说明已注明），仅用于混合叠加，不应误认为透明抠图。
当前 tile/ 目录预留；游戏牌面仍由现有引擎组件绘制，避免未经确认替换牌面造成规则图案偏差。
